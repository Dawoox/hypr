#!/usr/bin/env python3
import json, dns.resolver, dns.exception

from collections import Counter

def base_domain(host):
    """aspmx.l.google.com -> google.com"""
    parts = host.split('.')
    return '.'.join(parts[-3:] if len(parts) > 2 and len(parts[-1]) == 2
                    and parts[-2] in ('co', 'com', 'org', 'ac', 'net', 'gov')
                    else parts[-2:])

def main():
    with open('maintainer-list.json') as file:
        data = json.load(file)

    maintainers = [
        {'githubId': u['githubId'], 'email': u.get('email', None)}
        for u in data.values()
        if isinstance(u, dict) and u.get('githubId') is not None
    ]

    maintainers_with_email = {r["githubId"]: r["email"] for r in maintainers if r["email"]}
    missing = [r["githubId"] for r in maintainers if r["email"] is None]

    print(
        f"{len(maintainers)} maintainers in total: {len(maintainers_with_email)} with email address provided, {len(missing)} without one")

    domains = Counter(
        email_addr.split("@")[-1].strip().lower()
        for email_addr in maintainers_with_email.values()
    )

    print("\n20 most common domains in email addresses:")
    print('-' * 55)
    print(f"{'provider':<39} {'emails':>7} {'share':>6}")
    print('-' * 55)
    for provider, count in domains.most_common(20):
        print(f"{provider:<39} {count:>7} {count / domains.total():>7.1%}")

    provider_emails = Counter()

    print("\nfetching MX record of domains, this step take a long time (~10mn)... ", end='')
    for domain, count in domains.items():
        try:
            answer = dns.resolver.resolve(domain + '.', 'MX', raise_on_no_answer=False)
            if answer.rrset is None:
                key = '(no MX)'
            else:
                primary = sorted(answer.rrset, key=lambda r: r.preference)[0]
                key = base_domain(primary.exchange.to_text().rstrip('.').lower())
        except dns.resolver.NXDOMAIN:
            key = '(NXDOMAIN)'
        except dns.exception.DNSException:
            key = '(lookup failed)'

        provider_emails[key] += count
    print("Done.")

    print("\n20 most common email providers (by MX records):")
    print('-' * 55)
    print(f"{'provider':<39} {'emails':>7} {'share':>7}")
    print('-' * 55)
    for key, n in provider_emails.most_common(20):
        print(f"{key:<39} {n:>7} {n / provider_emails.total():>7.1%}")

if __name__ == '__main__':
    main()
